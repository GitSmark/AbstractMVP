package com.ttt.view.item;

import android.support.annotation.LayoutRes;
import android.view.View;
import android.widget.TextView;

import com.ttt.abstractmvp.R;
import com.ttt.common.adapter.AdapterItem;
import com.ttt.model.entity.MainListEntity;

public class MainListItem implements AdapterItem<MainListEntity>{

	TextView tv;
	
	@Override
	@LayoutRes
	public int getLayoutResId() {
		// TODO Auto-generated method stub
		return R.layout.listview_item;
	}

	@Override
	public void onBindViews(View root) {
		// TODO Auto-generated method stub
		tv = (TextView)root.findViewById(R.id.listview_tv);
	}

	@Override
	public void onSetViews() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onUpdateViews(MainListEntity model, int position) {
		// TODO Auto-generated method stub
		tv.setText(model.getName());
	}


}
