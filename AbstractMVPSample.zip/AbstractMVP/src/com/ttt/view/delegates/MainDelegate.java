package com.ttt.view.delegates;

import android.view.View.OnClickListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.ttt.abstractmvp.R;
import com.ttt.common.mvp.CommonActivity;
import com.ttt.common.mvp.CommonViewAdapterInterface;
import com.ttt.view.interfaces.MainInterface;

public abstract class MainDelegate extends CommonActivity implements OnClickListener, OnItemClickListener, CommonViewAdapterInterface, MainInterface {

	TextView tv;
	ListView lv;
	
	@Override
	public void initView() {
		// TODO Auto-generated method stub
		setContentView(R.layout.activity_main);
		tv = (TextView) findViewById(R.id.textview);
		lv = (ListView) findViewById(R.id.listview);
		lv.setAdapter((BaseAdapter)getAdapter());
	}
	
	@Override
	public void setListener() {
		// TODO Auto-generated method stub
		tv.setOnClickListener(this);
		lv.setOnItemClickListener(this);
	}

	@Override
	public void setText() {
		// TODO Auto-generated method stub
		tv.setText("tttttttttttt");
	}

}
