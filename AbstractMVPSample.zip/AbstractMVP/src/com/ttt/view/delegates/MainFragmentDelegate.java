package com.ttt.view.delegates;

import android.view.View;
import android.view.View.OnClickListener;

import com.ttt.abstractmvp.R;
import com.ttt.common.mvp.CommonFragment;

public abstract class MainFragmentDelegate extends CommonFragment implements OnClickListener {

	@Override
	public int inflateView() {
		// TODO Auto-generated method stub
		return R.layout.fragment_main;
	}

	@Override
	public void initView(View view) {
		// TODO Auto-generated method stub
		// initView view.findViewbyId(R.id.xx);
	}

	@Override
	public void setListener() {
		// TODO Auto-generated method stub
		// setListener
	}


}
