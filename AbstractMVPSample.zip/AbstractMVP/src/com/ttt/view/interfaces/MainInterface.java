package com.ttt.view.interfaces;

public interface MainInterface {

	void setText();
}
