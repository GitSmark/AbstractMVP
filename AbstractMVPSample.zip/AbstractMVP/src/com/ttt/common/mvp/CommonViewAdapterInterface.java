package com.ttt.common.mvp;

import android.widget.Adapter;

public interface CommonViewAdapterInterface {
	
	Adapter getAdapter();
}
