package com.ttt.common.mvp;

public interface CommonActivityInterface {

	void initView();
	void setListener();
}
