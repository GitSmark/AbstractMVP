package com.ttt.presenter.activity;

import java.util.ArrayList;
import java.util.List;

import com.ttt.abstractmvp.R;
import com.ttt.model.adapter.MainListAdapter;
import com.ttt.model.entity.MainListEntity;
import com.ttt.view.delegates.MainDelegate;

import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Toast;

public class MainActivity extends MainDelegate {

	private List<MainListEntity> datas = new ArrayList<>();
	private MainListAdapter adapter = new MainListAdapter(datas);
	
	@Override
	public Adapter getAdapter() {
		// TODO Auto-generated method stub
		return adapter;
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.textview:
			for (int i = 0; i < 15; i++) {
				//加载数据
				datas.add(new MainListEntity(1,"tttt"+i));
			}
			adapter.setData(datas);
			setText();
			break;

		default:
			break;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		Toast.makeText(this, datas.get(arg2).getName(), Toast.LENGTH_LONG).show();
	}

}
