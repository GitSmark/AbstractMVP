package com.ttt.presenter.fragment;

import android.view.View;

import com.ttt.view.delegates.MainFragmentDelegate;

public class MainFragment extends MainFragmentDelegate{

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}

}
