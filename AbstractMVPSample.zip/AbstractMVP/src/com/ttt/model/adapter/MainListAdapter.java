package com.ttt.model.adapter;

import java.util.List;

import com.ttt.common.adapter.AdapterItem;
import com.ttt.common.adapter.CommonAdapter;
import com.ttt.view.item.MainListItem;

import android.support.annotation.NonNull;

public class MainListAdapter<T> extends CommonAdapter<T> {

	public MainListAdapter(List<T> data) {
		super(data);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public Object getItemType(T t) {
		// TODO Auto-generated method stub
		return super.getItemType(t);
	}

	@NonNull
	@Override
	public AdapterItem<T> onCreateItem(Object type) {
		// TODO Auto-generated method stub
		return (AdapterItem<T>) new MainListItem();
	}
	
	


}
